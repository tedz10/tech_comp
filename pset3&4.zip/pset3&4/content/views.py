from django.shortcuts import render
from models import Article
from models import Content, Image, Contributor

# Create your views here.

def homepage(request):
	articles = Article.objects.all()
	data = {'articles': articles}
	return render(request, 'homepage.html', data)

def secondpage(request,article_id):
	article = get_object_or_404(Article, pk=article_id)
	return render(request, 'secondpage.html', {'article':article})
