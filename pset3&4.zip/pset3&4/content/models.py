from __future__ import unicode_literals
from django.db import models
from tinymce import models as tinymce_models

# Create your models here.


class Content(models.Model):
    title = models.CharField(max_length=500)
    subtitle = models.CharField(max_length=500)
    contributors = models.ManyToManyField('Contributor',
                                          related_name='content')
    pub_date = models.DateTimeField('date published')

class Article(Content):
    text = tinymce_models.HTMLField()

class Image(Content):
    path = models.CharField(max_length=500)

    def info(self):
    	return '%s \n %s \n %s' % (self.title, self.subtitle, self.pub_date)

class Contributor(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)

    def die(self):
    	self.delete()

